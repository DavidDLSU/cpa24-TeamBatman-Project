# Minesweeper

A java implementation with a GUI of the video game called 'Minesweeper' Link to Wikipedia article: https://en.wikipedia.org/wiki/Minesweeper_(video_game)

To run: <br>
If using Intellij ensure that you have downloaded the src and resources folders, then using a compiler that can compile and run Language level 20 build and run App.java<br>
If using javac first ensure that you have download the src and bin folders, then a level above .\src\, use the following commands:<br>  
>    javac -d .\bin\ .\src\*.java <br>
>    cd .\bin\ <br>
>    java App <br>

