public class Square {
    //represents the square
}
