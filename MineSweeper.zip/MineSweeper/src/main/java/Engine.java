class SquareNode {
    private Square square;
    private SquareNode previous;
    private SquareNode next;

    public SquareNode(Square square) {
        this.square = square;
    }

    public Square getSquare() {
        return square;
    }

    public void setSquare(Square square) {
        this.square = square;
    }

    public SquareNode getPrevious() {
        return previous;
    }

    public void setPrevious(SquareNode previous) {
        this.previous = previous;
    }

    public SquareNode getNext() {
        return next;
    }

    public void setNext(SquareNode next) {
        this.next = next;
    }
}

class Board {
    private SquareNode head;
    private SquareNode tail;
    private int size;

    public Board(int height, int width, int numBombs) {
        // Your code to create the board with the specified height, width, and number of bombs
    }

    public void revealSquare(int x, int y) {
        // Your code to reveal the square at the specified coordinates
    }

    public boolean checkWin() {
        // Your code to check if the game has been won
        return false;
    }

    public void gameOver(int x, int y) {
        // Your code to end the game and reveal all the bombs
    }

    public Square getSquare(int position) {
        // Your code to get the square at the specified position
        return null;
    }
}

