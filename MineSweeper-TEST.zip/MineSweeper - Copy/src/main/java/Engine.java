class SquareNode {
    private Square square;
    private SquareNode previous;
    private SquareNode next;

    public SquareNode(Square square) {
        this.square = square;
    }

    public Square getSquare() {
        return square;
    }

    public void setSquare(Square square) {
        this.square = square;
    }

    public SquareNode getPrevious() {
        return previous;
    }

    public void setPrevious(SquareNode previous) {
        this.previous = previous;
    }

    public SquareNode getNext() {
        return next;
    }

    public void setNext(SquareNode next) {
        this.next = next;
    }
}

class Board {
    private SquareNode head;
    private SquareNode tail;
    private int size;
    private int height;
    private int width; // Add width as a member variable
    private GUI gui;
    public Board(int height, int width, int numBombs, GUI gui) {
        // Initialize an empty board
        head = null;
        tail = null;
        size = height * width;
        this.height = height;
        this.width = width; // Set the width
        this.gui = gui;

        // Create the board with empty squares
        for (int i = 0; i < size; i++) {
            SquareNode newNode = new SquareNode(new Square());
            if (head == null) {
                head = newNode;
                tail = newNode;
            } else {
                tail.setNext(newNode);
                newNode.setPrevious(tail);
                tail = newNode;
            }
        }

        initializeBoard(numBombs);
    }

    public void initializeBoard(int numBombs) {
        int totalBombsPlaced = 0;
        int randInt;

        while (totalBombsPlaced < numBombs) {
            randInt = (int) (Math.random() * size);
            SquareNode bombNode = getNodeAtPosition(randInt);

            if (bombNode != null && !bombNode.getSquare().getIsBomb()) {
                bombNode.getSquare().updateIsBomb(true);
                totalBombsPlaced++;
            }
        }

        for (int positionLoop = 0; positionLoop < size; positionLoop++) {
            int x = positionLoop % width;
            int y = positionLoop / width;

            if (!getSquare(x, y).getIsBomb()) {
                int bombsAround = countBombsAround(x, y);
                getSquare(x, y).updateNumBombsAround(bombsAround);
            }
        }
    }

    private int countBombsAround(int x, int y) {
        int bombsAround = 0;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int newX = x + i;
                int newY = y + j;

                if (isValidPosition(newX, newY)) {
                    SquareNode neighborNode = getNodeAtPosition(newY * width + newX);
                    if (neighborNode != null && neighborNode.getSquare().getIsBomb()) {
                        bombsAround++;
                    }
                }
            }
        }

        if (bombsAround >= 5) {
            // If the count is 5 or greater, turn the square into a bomb
            SquareNode current = getNodeAtPosition(y * width + x);
            if (current != null) {
                current.getSquare().updateIsBomb(true);
            }
        }

        return bombsAround;
    }


    public SquareNode getNodeAtPosition(int position) {
        SquareNode current = head;
        for (int i = 0; i < position && current != null; i++) {
            current = current.getNext();
        }
        return current;
    }

    public boolean isValidPosition(int x, int y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    public void clickSquare(int x, int y, GUI gui) {
        int position = y * width + x;
        SquareNode squareNode = getNodeAtPosition(position);

        if (squareNode == null || squareNode.getSquare().getRevealed() || squareNode.getSquare().getFlagged()) {
            return;
        }

        squareNode.getSquare().updateRevealed(true);

        // Remove the action listener from the square
        gui.removeActionListener(x, y);

        if (squareNode.getSquare().getNumBombsAround() == 0) {
            gui.updatePaintedSquare(x, y, gui.CLEAR);

            // Reveal all squares around this square if they are blank and not already revealed
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    int newX = x + i;
                    int newY = y + j;

                    if (isValidPosition(newX, newY)) {
                        clickSquare(newX, newY, gui);
                    }
                }
            }
        } else if (squareNode.getSquare().getNumBombsAround() >= 5) {
            // If the square has a number between 5 and 8 and it's the only square clicked, end the game
            int revealedCount = countRevealedAround(x, y);
            if (revealedCount == 1) {
                gui.updatePaintedSquare(x, y, gui.BOMB);
                gui.endGame(false);
            } else {
                // If not the only square clicked, update the square without revealing it
                gui.updateHiddenSquare(x, y);
            }
        } else {
            gui.updateNumberedSquare(x, y, squareNode.getSquare().getNumBombsAround());
        }

        if (checkWin()) {
            // End the game with a win
            gui.endGame(true);
        }
    }

    private int countRevealedAround(int x, int y) {
        int revealedCount = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int newX = x + i;
                int newY = y + j;

                if (isValidPosition(newX, newY) && getSquare(newX, newY).getRevealed()) {
                    revealedCount++;
                }
            }
        }
        return revealedCount;
    }

    public boolean checkWin() {
        for (int positionLoop = 0; positionLoop < (height * width); positionLoop++) {
            int x = positionLoop % width;
            int y = (positionLoop - x) / width;

            Square currentSquare = getSquare(x, y);

            if (currentSquare.getIsBomb()) {
                // If a bomb square is revealed, the game is lost
                if (currentSquare.getRevealed()) {
                    return false;
                }

                // If a bomb square is not flagged, the game is not won
                if (!currentSquare.getFlagged()) {
                    return false;
                }
            } else {
                // If a non-bomb square is not revealed, the game is not won
                if (!currentSquare.getRevealed()) {
                    return false;
                }
            }
        }

        // All non-bomb squares are revealed and all bombs are correctly flagged
        return true;
    }



    public void gameOver(int x, int y) {
        for (int positionLoop = 0; positionLoop < (height * width); positionLoop++) {
            int i = positionLoop % width;
            int j = (positionLoop - i) / width;

            Square placeholder = getSquare(i, j);

            if (!placeholder.getRevealed()) {
                if (placeholder.getIsBomb()) {
                    if (placeholder.getFlagged()) {
                        // need to show that it was correctly flagged
                        gui.updatePaintedSquare(i, j, gui.BOMBFLAGGEDCORRECT);
                    } else {
                        // need to show that there was a bomb there
                        gui.updatePaintedSquare(i, j, gui.BOMB);
                    }
                } else if (placeholder.getFlagged()) {
                    // need to show that it was incorrectly flagged
                    gui.updatePaintedSquare(i, j, gui.BOMBFLAGGEDWRONG);
                }
                // otherwise leave as was
            }
        }

        // change the clicked square
        gui.updatePaintedSquare(x, y, gui.BOMBCLICKED);
        gui.endGame(false);
    }

    public Square getSquare(int x, int y) {
        int position = y * width + x;
        SquareNode squareNode = getNodeAtPosition(position);
        return squareNode != null ? squareNode.getSquare() : null;
    }
}
